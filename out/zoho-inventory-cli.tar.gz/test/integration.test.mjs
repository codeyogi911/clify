// Integration tests against the bundled mock server. Exercises the full
// HTTP path: Zoho's page-based pagination across two pages, the structured
// error map, page_context envelope handling, and BASE_URL override.
import test from "node:test";
import assert from "node:assert/strict";
import { mockApi } from "./_mock-server.mjs";
import { runJson } from "./_helpers.mjs";

const ENV = { ZOHO_INVENTORY_API_KEY: "test-token" };

async function withMock(routes, fn) {
  const server = await mockApi(routes);
  try { await fn(server); } finally { await server.close(); }
}

// ---------- items resource ----------

test("items list returns array via page_context envelope", async () => {
  await withMock({
    "GET /items": { status: 200, body: { items: [{ item_id: "1" }, { item_id: "2" }], page_context: { page: 1, per_page: 200, has_more_page: false } } },
  }, async (server) => {
    const r = await runJson(["items", "list"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(r.json.items.length, 2);
    assert.equal(server.requests[0].method, "GET");
    assert.equal(server.requests[0].path, "/items");
  });
});

test("items list --all walks multi-page pagination via page_context.has_more_page", async () => {
  await withMock({
    "GET /items": (req) => {
      const page = req.query.page || "1";
      if (page === "1") return { status: 200, body: { items: [{ item_id: "1" }, { item_id: "2" }], page_context: { page: 1, per_page: 2, has_more_page: true } } };
      if (page === "2") return { status: 200, body: { items: [{ item_id: "3" }], page_context: { page: 2, per_page: 2, has_more_page: false } } };
      return { status: 400, body: { message: "unknown page" } };
    },
  }, async (server) => {
    const r = await runJson(["items", "list", "--all"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(r.json.length, 3);
    assert.deepEqual(r.json.map((i) => i.item_id), ["1", "2", "3"]);
    assert.equal(server.requests.length, 2);
    assert.equal(server.requests[0].query.page, "1");
    assert.equal(server.requests[1].query.page, "2");
  });
});

test("items get interpolates id into path", async () => {
  await withMock({
    "GET /items/:id": (_req, params) => ({ status: 200, body: { item: { item_id: params.id, name: "Widget" } } }),
  }, async (server) => {
    const r = await runJson(["items", "get", "--id", "42"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(r.json.item.item_id, "42");
    assert.equal(server.requests[0].path, "/items/42");
  });
});

test("items create sends body fields as JSON", async () => {
  await withMock({
    "POST /items": (req) => ({ status: 201, body: { item: { item_id: "new", ...req.body } } }),
  }, async (server) => {
    const r = await runJson(
      ["items", "create", "--name", "Widget", "--sku", "W-001", "--rate", "9.99"],
      { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } }
    );
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(r.json.item.item_id, "new");
    assert.equal(r.json.item.name, "Widget");
    assert.deepEqual(server.requests[0].body, { name: "Widget", sku: "W-001", rate: "9.99" });
    assert.equal(server.requests[0].headers["content-type"], "application/json");
  });
});

test("items update sends PUT with body", async () => {
  await withMock({
    "PUT /items/:id": (req, params) => ({ status: 200, body: { item: { item_id: params.id, ...req.body } } }),
  }, async (server) => {
    const r = await runJson(
      ["items", "update", "--id", "7", "--name", "Updated"],
      { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } }
    );
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(server.requests[0].method, "PUT");
    assert.equal(server.requests[0].body.name, "Updated");
  });
});

test("items delete returns null body", async () => {
  await withMock({
    "DELETE /items/:id": { status: 200, body: { code: 0, message: "success" } },
  }, async (server) => {
    const r = await runJson(["items", "delete", "--id", "9"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(server.requests[0].method, "DELETE");
    assert.equal(server.requests[0].path, "/items/9");
  });
});

// ---------- contacts resource ----------

test("contacts list filters by contact_type_filter query", async () => {
  await withMock({
    "GET /contacts": (req) => ({ status: 200, body: { contacts: [{ contact_id: "c1", contact_type: req.query.contact_type_filter }], page_context: { page: 1, per_page: 200, has_more_page: false } } }),
  }, async (server) => {
    const r = await runJson(["contacts", "list", "--contact_type_filter", "customers"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(server.requests[0].query.contact_type_filter, "customers");
  });
});

test("contacts create sends contact_name + email", async () => {
  await withMock({
    "POST /contacts": (req) => ({ status: 201, body: { contact: { contact_id: "c-new", ...req.body } } }),
  }, async (server) => {
    const r = await runJson(
      ["contacts", "create", "--contact_name", "Acme Inc.", "--email", "ap@acme.test", "--contact_type", "customer"],
      { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } }
    );
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(r.json.contact.contact_name, "Acme Inc.");
    assert.equal(server.requests[0].body.email, "ap@acme.test");
  });
});

// ---------- sales-orders + raw body escape hatch ----------

test("sales-orders create with --body posts the literal JSON", async () => {
  await withMock({
    "POST /salesorders": (req) => ({ status: 201, body: { salesorder: { salesorder_id: "so-1", ...req.body } } }),
  }, async (server) => {
    const payload = { customer_id: "cust-1", date: "2026-04-26", line_items: [{ item_id: "i-1", quantity: 2 }] };
    const r = await runJson(
      ["sales-orders", "create", "--body", JSON.stringify(payload)],
      { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } }
    );
    assert.equal(r.exitCode, 0, r.stderr);
    assert.deepEqual(server.requests[0].body, payload);
  });
});

// ---------- composite-items ----------

test("composite-items get returns mapped_items array", async () => {
  await withMock({
    "GET /compositeitems/:id": (_req, params) => ({
      status: 200,
      body: { composite_item: { composite_item_id: params.id, name: "Kit", mapped_items: [{ item_id: "a", quantity: 1 }] } },
    }),
  }, async (server) => {
    const r = await runJson(["composite-items", "get", "--id", "k1"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(r.json.composite_item.mapped_items.length, 1);
  });
});

// ---------- error paths ----------

test("404 → not_found", async () => {
  await withMock({ "GET /items/:id": { status: 404, body: { code: 1001, message: "nope" } } }, async (server) => {
    const r = await runJson(["items", "get", "--id", "999"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 1);
    assert.equal(r.errJson.code, "not_found");
    assert.equal(r.errJson.retryable, false);
  });
});

test("422 → validation_error with details", async () => {
  await withMock({ "POST /items": { status: 422, body: { code: 1002, message: "bad", errors: ["name required"] } } }, async (server) => {
    const r = await runJson(["items", "create", "--name", ""], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 1);
    assert.equal(r.errJson.code, "validation_error");
    assert.ok(r.errJson.details);
  });
});

test("429 with Retry-After → rate_limited + retryAfter", async () => {
  await withMock({ "GET /items": { status: 429, headers: { "retry-after": "30" }, body: { code: 45, message: "slow down" } } }, async (server) => {
    const r = await runJson(["items", "list"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 1);
    assert.equal(r.errJson.code, "rate_limited");
    assert.equal(r.errJson.retryable, true);
    assert.equal(r.errJson.retryAfter, 30);
  });
});

test("500 → server_error retryable", async () => {
  await withMock({ "GET /items": { status: 500, body: { message: "boom" } } }, async (server) => {
    const r = await runJson(["items", "list"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 1);
    assert.equal(r.errJson.code, "server_error");
    assert.equal(r.errJson.retryable, true);
  });
});

test("network down → network_error", async () => {
  const server = await mockApi({});
  const url = server.url;
  await server.close();
  const r = await runJson(["items", "list"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: url } });
  assert.equal(r.exitCode, 1);
  assert.equal(r.errJson.code, "network_error");
  assert.equal(r.errJson.retryable, true);
});

// ---------- env wiring ----------

test("BASE_URL override is honored", async () => {
  await withMock({ "GET /items": { status: 200, body: { items: [], page_context: { has_more_page: false } } } }, async (server) => {
    const r = await runJson(["items", "list"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.equal(r.exitCode, 0);
    assert.equal(server.requests.length, 1);
  });
});

test("user-agent header is sent", async () => {
  await withMock({ "GET /items": { status: 200, body: { items: [], page_context: { has_more_page: false } } } }, async (server) => {
    await runJson(["items", "list"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url } });
    assert.match(server.requests[0].headers["user-agent"], /zoho-inventory-cli\//);
  });
});

test("organization_id is auto-attached when ZOHO_INVENTORY_ORG_ID is set", async () => {
  await withMock({ "GET /items": (req) => ({ status: 200, body: { items: [{ item_id: req.query.organization_id }], page_context: { has_more_page: false } } }) }, async (server) => {
    const r = await runJson(["items", "list"], { env: { ...ENV, ZOHO_INVENTORY_BASE_URL: server.url, ZOHO_INVENTORY_ORG_ID: "org-42" } });
    assert.equal(r.exitCode, 0, r.stderr);
    assert.equal(server.requests[0].query.organization_id, "org-42");
  });
});
