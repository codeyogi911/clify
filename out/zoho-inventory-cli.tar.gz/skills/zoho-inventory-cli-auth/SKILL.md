---
name: zoho-inventory-cli-auth
description: Manage authentication for the Zoho Inventory API via zoho-inventory-cli login. Use when the user asks how to authenticate, refresh an OAuth token, store credentials, or troubleshoot 401/403 errors.
allowed-tools:
  - Bash
  - Read
---

# zoho-inventory-cli-auth

Manage credentials for `zoho-inventory-cli`. Zoho Inventory uses **OAuth 2.0 with rotating access tokens and a long-lived refresh token**. The header sent on every request is `Authorization: Zoho-oauthtoken <access_token>` — the prefix is Zoho-specific and is **not** RFC 6750 `Bearer`.

For the full refresh flow, read `knowledge/oauth-refresh.md`. For the regional-host map (the OAuth endpoint differs per data center), read `knowledge/multi-region.md`.

## Where the token lives

`zoho-inventory-cli` reads its access token in this order:

1. `ZOHO_INVENTORY_API_KEY` from the environment (or `.env`).
2. The `token` field of `~/.config/zoho-inventory-cli/credentials.json`, written by `zoho-inventory-cli login`.

If neither is set, every command fails with `auth_missing`.

## Initial setup

1. Register a **Self Client** at https://api-console.zoho.com to obtain `client_id` and `client_secret`.
2. Generate a one-time grant for scope `ZohoInventory.fullaccess.all` (or narrower scopes — see Anti-patterns below).
3. Exchange the grant against `https://accounts.zoho.<region>/oauth/v2/token` for a `refresh_token` + initial `access_token`.
4. Run `zoho-inventory-cli login --token <access_token>` to persist it. Keep the `refresh_token` in your secrets manager.

## Login

```
zoho-inventory-cli login --token <access_token>
```

Stores the access token at `~/.config/zoho-inventory-cli/credentials.json` (mode 0600).

```
zoho-inventory-cli login --status --json
```

Reports `{ scheme, envVar, fromEnv, fromConfig, authenticated }` so you can see which source is providing auth.

## Refresh flow (every 60 minutes)

The CLI does **not** auto-refresh. When `auth_invalid` fires:

```
POST https://accounts.zoho.<region>/oauth/v2/token
Content-Type: application/x-www-form-urlencoded

refresh_token=<saved>&client_id=<id>&client_secret=<secret>&grant_type=refresh_token
```

Response: `{ access_token, expires_in, api_domain, token_type }`. Persist with `zoho-inventory-cli login --token <new>`, then retry the original command.

`api_domain` is the canonical signal of which region this token serves. If `api_domain` differs from `https://www.zohoapis.<ZOHO_INVENTORY_REGION>`, update `ZOHO_INVENTORY_REGION` accordingly.

## Errors and remediation

| Code | HTTP | Likely cause | Action |
|---|---|---|---|
| `auth_missing` | — | No env var, no stored credentials | Set `ZOHO_INVENTORY_API_KEY` or run `login` |
| `auth_invalid` | 401 | Access token expired or rotated | Refresh against `accounts.zoho.<region>` and run `login` again |
| `forbidden`    | 403 | Token valid but lacks scope, or wrong region | Check OAuth scope on the Self Client; verify `ZOHO_INVENTORY_REGION` matches `api_domain` |

The CLI does not retry auth errors. Refresh once per command — if a second `auth_invalid` follows a successful refresh, the refresh token itself is dead (revoked or client secret rotated); surface to the user.

## Anti-patterns

- ❌ Don't paste tokens into source files. The validation gate scans for `Bearer <token>` patterns.
- ❌ Don't share `~/.config/zoho-inventory-cli/credentials.json` between machines — re-run `login` per machine.
- ❌ Don't request `ZohoInventory.fullaccess.all` if a narrower scope works — most read-only agent flows only need `ZohoInventory.items.READ`, `ZohoInventory.contacts.READ`, etc.
- ❌ Don't refresh against `accounts.zoho.com` if the user is on `eu`/`in`/etc. — the refresh fails with `invalid_code` and the message is unhelpful.
