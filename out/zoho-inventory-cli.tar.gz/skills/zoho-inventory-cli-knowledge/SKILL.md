---
name: zoho-inventory-cli-knowledge
description: Capture and consult business rules and runtime quirks for the Zoho Inventory API. Use when the user asks "what are the gotchas with this API?" or wants to record a finding that should persist across sessions.
allowed-tools:
  - Read
  - Write
---

# zoho-inventory-cli-knowledge

API knowledge for Zoho Inventory lives under `knowledge/`. Each file has YAML frontmatter and a free-form body.

## When to read

Before any non-trivial workflow, read every file in `knowledge/`. The files are small by design — meant to be read in full, not searched.

## When to write

After a workflow surfaces a non-obvious finding (an undocumented constraint, a sequencing requirement, a plan-tier limit, an enum value not in the docs), append a new file. Filename: `knowledge/<short-topic>.md`. Frontmatter:

```yaml
---
type: gotcha | pattern | shortcut | quirk | business-rule
applies-to: ["items.create", "sales-orders.create"]   # optional but useful
source: docs | runtime
confidence: high | medium | low
extracted: 2026-04-26
---
```

Body: prose. Cite the surface that produced the finding (Zoho response message, dashboard string, runtime error). Don't include API secrets.

## Existing knowledge

| File | Type | Applies to |
|---|---|---|
| `knowledge/oauth-refresh.md`   | business-rule | every list/get/create/update/delete (auth precondition) |
| `knowledge/multi-region.md`    | business-rule | every request (host selection) |
| `knowledge/composite-items.md` | business-rule | `composite-items.*`, indirectly `sales-orders.create` |
| `knowledge/rate-limit.md`      | pattern       | every request |

## Anti-patterns

- ❌ Don't write nuance prose into `knowledge/` if the corresponding `.clify.json.nuances.*` field isn't set; the validation gate cross-references them.
- ❌ Don't duplicate help text — the CLI's `--help` is the source of truth for flag shapes.
- ❌ Don't keep stale entries. When the API changes (`clify sync-check` reports drift), prune knowledge that no longer applies.
