---
name: zoho-inventory-cli-resources
description: Quick reference for every Zoho Inventory API resource × action exposed by zoho-inventory-cli. Use when the user asks "what does the items API support?" or needs the precise flag set for a specific endpoint.
allowed-tools:
  - Bash
  - Read
---

# zoho-inventory-cli-resources

Resource × action quick reference. When in doubt, prefer `zoho-inventory-cli <resource> <action> --help` — the help text is generated from the same registry the dispatcher reads, so it never drifts.

Every list action accepts `--page` and `--per_page`. Combine with global `--all` to walk pages until `page_context.has_more_page` is false.

## organizations

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list | GET | /organizations     | — | `--page`, `--per_page` |
| get  | GET | /organizations/:id | `--id` | — |

## contacts

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET    | /contacts     | — | `--contact_type_filter` (customers\|vendors), `--search_text` |
| get    | GET    | /contacts/:id | `--id` | — |
| create | POST   | /contacts     | — (Zoho requires `--contact_name`) | `--company_name`, `--email`, `--phone`, `--contact_type`, `--body` |
| update | PUT    | /contacts/:id | `--id` | same as create |
| delete | DELETE | /contacts/:id | `--id` | — |

## items

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET    | /items     | — | `--search_text`, `--category_id` |
| get    | GET    | /items/:id | `--id` | — |
| create | POST   | /items     | — (Zoho requires `--name`, `--rate`) | `--sku`, `--unit`, `--product_type`, `--description`, `--body` |
| update | PUT    | /items/:id | `--id` | same as create |
| delete | DELETE | /items/:id | `--id` | — |

## composite-items

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET    | /compositeitems     | — | `--search_text` |
| get    | GET    | /compositeitems/:id | `--id` | — |
| create | POST   | /compositeitems     | — | `--body` (required for `mapped_items[]`), `--name`, `--rate` |
| update | PUT    | /compositeitems/:id | `--id` | same as create — note recipe-lock rules in `knowledge/composite-items.md` |
| delete | DELETE | /compositeitems/:id | `--id` | — |

## sales-orders

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET    | /salesorders     | — | `--status` (draft\|open\|invoiced\|void), `--search_text` |
| get    | GET    | /salesorders/:id | `--id` | — |
| create | POST   | /salesorders     | — | `--body` (for `line_items[]`), `--customer_id`, `--date`, `--reference_number` |
| update | PUT    | /salesorders/:id | `--id` | same — `invoiced`/`void` orders reject edits |
| delete | DELETE | /salesorders/:id | `--id` | — |

## invoices

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET    | /invoices     | — | `--status` (draft\|sent\|paid\|overdue\|void), `--customer_id_filter` |
| get    | GET    | /invoices/:id | `--id` | — |
| create | POST   | /invoices     | — | `--body` (for `line_items[]`), `--customer_id`, `--date`, `--due_date` |
| update | PUT    | /invoices/:id | `--id` | same — paid invoices reject `line_items` edits |
| delete | DELETE | /invoices/:id | `--id` | — |

## purchase-orders

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET    | /purchaseorders     | — | `--status` (draft\|open\|billed\|closed) |
| get    | GET    | /purchaseorders/:id | `--id` | — |
| create | POST   | /purchaseorders     | — | `--body` (for `line_items[]`), `--vendor_id`, `--date`, `--delivery_date` |
| update | PUT    | /purchaseorders/:id | `--id` | same as create |
| delete | DELETE | /purchaseorders/:id | `--id` | — |

## inventory-adjustments

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET  | /inventoryadjustments     | — | `--from_date`, `--to_date` |
| get    | GET  | /inventoryadjustments/:id | `--id` | — |
| create | POST | /inventoryadjustments     | — | `--body` (for `line_items[]`), `--date`, `--reason`, `--adjustment_type` |

## customer-payments

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list   | GET  | /customerpayments     | — | `--customer_id_filter` |
| get    | GET  | /customerpayments/:id | `--id` | — |
| create | POST | /customerpayments     | — | `--body` (for `invoices[]`), `--customer_id`, `--payment_mode`, `--amount`, `--date` |

## packages

| Action | Method | Path | Required flags | Notable optional |
|---|---|---|---|---|
| list | GET | /packages     | — | `--status` (not_shipped\|shipped\|delivered) |
| get  | GET | /packages/:id | `--id` | — |

## Patterns shared across resources

- **Page-based pagination** — `list` actions accept `--page` and `--per_page`. With `--all`, the CLI walks pages until `page_context.has_more_page` is false.
- **Raw JSON escape hatch** — every `create`/`update` accepts `--body '<json>'` to send a raw payload (the only way to supply array-shaped fields like `line_items[]`).
- **Auto org_id** — when `ZOHO_INVENTORY_ORG_ID` is set, every request gets `?organization_id=...` attached.
- **Multi-region** — `ZOHO_INVENTORY_REGION` selects the data center; see `knowledge/multi-region.md`.
