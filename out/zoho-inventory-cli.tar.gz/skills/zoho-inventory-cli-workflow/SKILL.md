---
name: zoho-inventory-cli-workflow
description: Drive end-to-end workflows on the Zoho Inventory API via zoho-inventory-cli. Use when the user asks to list/get/create/update/delete organizations, contacts, items, composite-items, sales-orders, invoices, purchase-orders, inventory-adjustments, customer-payments, or packages, or to chain multiple Zoho Inventory operations together.
allowed-tools:
  - Bash
  - Read
  - Write
---

# zoho-inventory-cli-workflow

Wrap the [Zoho Inventory API](https://www.zoho.com/inventory/api/v1/introduction/) via `zoho-inventory-cli`. Zoho Inventory is a multi-region SaaS — every request resolves against `https://www.zohoapis.<region>/inventory/v1` and authenticates with an OAuth 2.0 access token sent as `Authorization: Zoho-oauthtoken <token>` (the prefix is Zoho-specific, not RFC 6750 Bearer).

**Before running any command, read every file in `knowledge/`** — especially `oauth-refresh.md`, `multi-region.md`, `composite-items.md`, and `rate-limit.md`. Each captures a Zoho-specific quirk that will surprise you in production.

## Triggers

- User says `/zoho-inventory-cli` or `/zoho-inventory`
- User asks to manipulate `organizations`, `contacts`, `items`, `composite-items`, `sales-orders`, `invoices`, `purchase-orders`, `inventory-adjustments`, `customer-payments`, or `packages` on Zoho Inventory
- User asks to walk a paginated list across all pages
- User asks how to handle a 401 (refresh flow) or 429 (rate limit)

## Setup

The CLI needs an OAuth access token and the data-center region. Set in `.env` or environment:

```
ZOHO_INVENTORY_API_KEY=<access_token>            # 60-min lifetime; refresh per knowledge/oauth-refresh.md
ZOHO_INVENTORY_REGION=com                        # com | eu | in | com.au | jp | ca | com.cn | sa
ZOHO_INVENTORY_ORG_ID=<organization_id>          # auto-attached to every request
```

Confirm with:

```
zoho-inventory-cli login --status --json
zoho-inventory-cli organizations list --json     # validation request
```

For tests, point at a mock server with `ZOHO_INVENTORY_BASE_URL=http://127.0.0.1:<port>` (overrides region routing).

## Quick reference

| Resource | Actions | Notes |
|---|---|---|
| `organizations`         | list, get                          | Read-only; pick `organization_id` to set `ZOHO_INVENTORY_ORG_ID` |
| `contacts`              | list, get, create, update, delete  | Customers + vendors (filter via `--contact_type_filter`) |
| `items`                 | list, get, create, update, delete  | Goods/services/digital-services |
| `composite-items`       | list, get, create, update, delete  | Kits/assemblies; see `knowledge/composite-items.md` for stock rules |
| `sales-orders`          | list, get, create, update, delete  | Open commitments from customers; `--body` for `line_items[]` |
| `invoices`              | list, get, create, update, delete  | Customer-facing billing |
| `purchase-orders`       | list, get, create, update, delete  | Vendor-facing buying |
| `inventory-adjustments` | list, get, create                  | Stock corrections |
| `customer-payments`     | list, get, create                  | Payments applied against invoices |
| `packages`              | list, get                          | Shipping packages |

Login is dispatched separately: `zoho-inventory-cli login [--token <t>] [--status]`.

Use `zoho-inventory-cli <resource> <action> --help` for per-action flags.

## Global flags

- `--json` — force JSON output (auto when piped)
- `--dry-run` — print request without sending
- `--verbose` — print response status & headers to stderr
- `--all` — auto-paginate list actions (page-based, walks `page_context.has_more_page`)
- `--version`, `-v`
- `--help`, `-h`

## Knowledge system

Read every file in `knowledge/` before issuing commands. After a workflow surfaces a non-obvious finding (an undocumented constraint, a sequencing requirement, a plan-tier limit), append a new file at `knowledge/<short-topic>.md` with frontmatter `type:` set to `gotcha`, `pattern`, `shortcut`, `quirk`, or `business-rule`.

## Common workflows

### 1. Discover the user's organization id

```
zoho-inventory-cli organizations list --json | jq '.organizations[] | { organization_id, name }'
```

Set `ZOHO_INVENTORY_ORG_ID` to the chosen id; the CLI will auto-attach it on subsequent calls.

### 2. Walk a paginated list

```
zoho-inventory-cli items list --all --json | jq '. | length'
```

The CLI walks `page_context.has_more_page` page-by-page until the server returns `has_more_page: false`.

### 3. Create a sales order with line items

`line_items[]` is array-shaped, so use `--body` rather than per-line flags:

```
zoho-inventory-cli sales-orders create --body '{
  "customer_id": "5210000000123",
  "date": "2026-04-26",
  "line_items": [
    { "item_id": "5210000000456", "quantity": 2, "rate": "9.99" }
  ]
}'
```

### 4. Refresh an expired access token

The CLI surfaces `code: "auth_invalid"` (HTTP 401) when the access token expires (every 60 min). The agent loop should:

1. POST to `https://accounts.zoho.<region>/oauth/v2/token` with `grant_type=refresh_token`, `refresh_token=<saved>`, `client_id`, `client_secret`.
2. Run `zoho-inventory-cli login --token <new_access_token>` to persist the new token.
3. Re-issue the original command.

Loop at most once per command — see `knowledge/oauth-refresh.md`.

### 5. Handle 429 rate limit

The CLI returns `code: "rate_limited", retryable: true, retryAfter: <seconds>`. Sleep for `retryAfter` and re-issue. If the message is `"daily API call limit exceeded"`, do **not** retry — wait until UTC midnight (see `knowledge/rate-limit.md`).
