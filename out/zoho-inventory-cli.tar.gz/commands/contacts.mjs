// `contacts` resource — customers and vendors. Page-based pagination on list.
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body (overrides individual flags)" },
  contact_name: { type: "string", description: "Display name (required by Zoho on create)" },
  company_name: { type: "string", description: "Company name" },
  contact_type: { type: "string", description: "customer | vendor" },
  email: { type: "string", description: "Primary email" },
  phone: { type: "string", description: "Primary phone" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "contact_type_filter", "search_text"]);

export default {
  name: "contacts",
  actions: {
    list: {
      method: "GET",
      path: "/contacts",
      description: "List contacts (customers + vendors). Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        contact_type_filter: { type: "string", description: "Filter by type: customers | vendors" },
        search_text: { type: "string", description: "Free-text search across name/email/phone" },
      },
    },
    get: {
      method: "GET",
      path: "/contacts/:id",
      description: "Fetch a single contact by id.",
      flags: { id: { type: "string", required: true, description: "Contact id" } },
    },
    create: {
      method: "POST",
      path: "/contacts",
      description: "Create a contact. `contact_name` is required.",
      flags: { ...COMMON_BODY_FLAGS },
    },
    update: {
      method: "PUT",
      path: "/contacts/:id",
      description: "Update a contact.",
      flags: {
        id: { type: "string", required: true, description: "Contact id" },
        ...COMMON_BODY_FLAGS,
      },
    },
    delete: {
      method: "DELETE",
      path: "/contacts/:id",
      description: "Delete a contact.",
      flags: { id: { type: "string", required: true, description: "Contact id" } },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
