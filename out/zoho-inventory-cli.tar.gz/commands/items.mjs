// `items` resource — products and services tracked by Zoho Inventory.
// Page-based pagination on list (see lib/api.mjs).
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body (overrides individual flags)" },
  name: { type: "string", description: "Item name (required on create)" },
  sku: { type: "string", description: "Stock keeping unit identifier" },
  rate: { type: "string", description: "Unit selling price as decimal string" },
  unit: { type: "string", description: "Measurement unit, e.g. \"pcs\" or \"kg\"" },
  product_type: { type: "string", description: "goods | service | digital_service" },
  description: { type: "string", description: "Free-form item description" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "search_text", "category_id"]);

export default {
  name: "items",
  actions: {
    list: {
      method: "GET",
      path: "/items",
      description: "List items. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        search_text: { type: "string", description: "Free-text search across name/sku/description" },
        category_id: { type: "string", description: "Filter by item category id" },
      },
    },
    get: {
      method: "GET",
      path: "/items/:id",
      description: "Fetch a single item by id.",
      flags: { id: { type: "string", required: true, description: "Item id" } },
    },
    create: {
      method: "POST",
      path: "/items",
      description: "Create an item. `name` and `rate` are required by Zoho.",
      flags: { ...COMMON_BODY_FLAGS },
    },
    update: {
      method: "PUT",
      path: "/items/:id",
      description: "Update an item.",
      flags: {
        id: { type: "string", required: true, description: "Item id" },
        ...COMMON_BODY_FLAGS,
      },
    },
    delete: {
      method: "DELETE",
      path: "/items/:id",
      description: "Delete an item.",
      flags: { id: { type: "string", required: true, description: "Item id" } },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
