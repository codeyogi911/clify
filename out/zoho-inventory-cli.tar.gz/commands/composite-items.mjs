// `composite-items` resource — Zoho's "kit" or "assembly" items composed of
// multiple component items. The component list lives on `mapped_items[]`,
// each entry referencing an existing item id + the quantity consumed when one
// composite is built. See knowledge/composite-items.md for the assembly-stock
// rule and the conditions under which assembly is rejected.
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body — required when supplying `mapped_items` (it's an array)" },
  name: { type: "string", description: "Composite item name (required on create)" },
  sku: { type: "string", description: "Composite SKU" },
  rate: { type: "string", description: "Selling price as decimal string" },
  unit: { type: "string", description: "Measurement unit" },
  product_type: { type: "string", description: "goods | service" },
  description: { type: "string", description: "Free-form description" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "search_text"]);

export default {
  name: "composite-items",
  actions: {
    list: {
      method: "GET",
      path: "/compositeitems",
      description: "List composite (kit/assembly) items. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        search_text: { type: "string", description: "Free-text search across name/sku" },
      },
    },
    get: {
      method: "GET",
      path: "/compositeitems/:id",
      description: "Fetch a single composite item by id (includes mapped_items).",
      flags: { id: { type: "string", required: true, description: "Composite item id" } },
    },
    create: {
      method: "POST",
      path: "/compositeitems",
      description: "Create a composite item. Pass --body to include the `mapped_items[]` array.",
      flags: { ...COMMON_BODY_FLAGS },
    },
    update: {
      method: "PUT",
      path: "/compositeitems/:id",
      description: "Update a composite item.",
      flags: {
        id: { type: "string", required: true, description: "Composite item id" },
        ...COMMON_BODY_FLAGS,
      },
    },
    delete: {
      method: "DELETE",
      path: "/compositeitems/:id",
      description: "Delete a composite item.",
      flags: { id: { type: "string", required: true, description: "Composite item id" } },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
