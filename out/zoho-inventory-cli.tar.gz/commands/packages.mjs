// `packages` resource. The shipping package for a sales order; tracks the
// physical fulfillment that becomes a shipment record.
export default {
  name: "packages",
  actions: {
    list: {
      method: "GET",
      path: "/packages",
      description: "List packages. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        status: { type: "string", description: "Filter by status: not_shipped | shipped | delivered" },
      },
    },
    get: {
      method: "GET",
      path: "/packages/:id",
      description: "Fetch a single package by id.",
      flags: { id: { type: "string", required: true, description: "Package id" } },
    },
  },
  buildPayload() { return {}; },
};
