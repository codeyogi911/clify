// `customer-payments` resource. Payments received against invoices.
// `invoices[]` (invoice_id + amount_applied) is array-shaped — use --body.
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body — required when supplying `invoices[]`" },
  customer_id: { type: "string", description: "Customer (contact) id (required on create)" },
  payment_mode: { type: "string", description: "cash | check | banktransfer | creditcard | stripe | ..." },
  amount: { type: "string", description: "Total payment amount as decimal string" },
  date: { type: "string", description: "Payment date (YYYY-MM-DD)" },
  reference_number: { type: "string", description: "Bank/check reference number" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "customer_id_filter"]);

export default {
  name: "customer-payments",
  actions: {
    list: {
      method: "GET",
      path: "/customerpayments",
      description: "List customer payments. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        customer_id_filter: { type: "string", description: "Filter by customer id" },
      },
    },
    get: {
      method: "GET",
      path: "/customerpayments/:id",
      description: "Fetch a single customer payment by id.",
      flags: { id: { type: "string", required: true, description: "Customer payment id" } },
    },
    create: {
      method: "POST",
      path: "/customerpayments",
      description: "Record a customer payment. Pass --body to apply against `invoices[]`.",
      flags: { ...COMMON_BODY_FLAGS },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
