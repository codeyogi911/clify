// `sales-orders` resource. Zoho calls these "Sales Orders" — the open
// commitment from a customer that becomes invoiceable once shipped/packed.
// `line_items[]` array typically supplied via --body since each line has 6+
// fields and ad-hoc flags don't model the array shape well.
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body — required when supplying `line_items[]`" },
  customer_id: { type: "string", description: "Customer (contact) id (required on create)" },
  date: { type: "string", description: "Order date (YYYY-MM-DD)" },
  reference_number: { type: "string", description: "Customer reference / PO number" },
  notes: { type: "string", description: "Free-form notes shown on the order" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "status", "search_text"]);

export default {
  name: "sales-orders",
  actions: {
    list: {
      method: "GET",
      path: "/salesorders",
      description: "List sales orders. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        status: { type: "string", description: "Filter by status: draft | open | invoiced | void" },
        search_text: { type: "string", description: "Free-text search" },
      },
    },
    get: {
      method: "GET",
      path: "/salesorders/:id",
      description: "Fetch a single sales order by id.",
      flags: { id: { type: "string", required: true, description: "Sales order id" } },
    },
    create: {
      method: "POST",
      path: "/salesorders",
      description: "Create a sales order. Pass --body to supply `line_items[]`.",
      flags: { ...COMMON_BODY_FLAGS },
    },
    update: {
      method: "PUT",
      path: "/salesorders/:id",
      description: "Update a sales order. Some statuses (`invoiced`, `void`) reject edits.",
      flags: {
        id: { type: "string", required: true, description: "Sales order id" },
        ...COMMON_BODY_FLAGS,
      },
    },
    delete: {
      method: "DELETE",
      path: "/salesorders/:id",
      description: "Delete a sales order.",
      flags: { id: { type: "string", required: true, description: "Sales order id" } },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
