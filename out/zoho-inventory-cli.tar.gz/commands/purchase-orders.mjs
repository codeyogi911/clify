// `purchase-orders` resource. The vendor-facing commitment to buy.
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body — required when supplying `line_items[]`" },
  vendor_id: { type: "string", description: "Vendor (contact) id (required on create)" },
  date: { type: "string", description: "Purchase order date (YYYY-MM-DD)" },
  delivery_date: { type: "string", description: "Expected delivery date (YYYY-MM-DD)" },
  reference_number: { type: "string", description: "Vendor reference number" },
  notes: { type: "string", description: "Free-form notes shown on the PO" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "status"]);

export default {
  name: "purchase-orders",
  actions: {
    list: {
      method: "GET",
      path: "/purchaseorders",
      description: "List purchase orders. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        status: { type: "string", description: "Filter by status: draft | open | billed | closed" },
      },
    },
    get: {
      method: "GET",
      path: "/purchaseorders/:id",
      description: "Fetch a single purchase order by id.",
      flags: { id: { type: "string", required: true, description: "Purchase order id" } },
    },
    create: {
      method: "POST",
      path: "/purchaseorders",
      description: "Create a purchase order. Pass --body to supply `line_items[]`.",
      flags: { ...COMMON_BODY_FLAGS },
    },
    update: {
      method: "PUT",
      path: "/purchaseorders/:id",
      description: "Update a purchase order.",
      flags: {
        id: { type: "string", required: true, description: "Purchase order id" },
        ...COMMON_BODY_FLAGS,
      },
    },
    delete: {
      method: "DELETE",
      path: "/purchaseorders/:id",
      description: "Delete a purchase order.",
      flags: { id: { type: "string", required: true, description: "Purchase order id" } },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
