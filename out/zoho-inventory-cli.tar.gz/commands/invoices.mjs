// `invoices` resource. The customer-facing billing document; usually created
// from a sales order. `line_items[]` are typically supplied via --body.
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body — required when supplying `line_items[]`" },
  customer_id: { type: "string", description: "Customer (contact) id (required on create)" },
  date: { type: "string", description: "Invoice date (YYYY-MM-DD)" },
  due_date: { type: "string", description: "Due date (YYYY-MM-DD)" },
  reference_number: { type: "string", description: "Customer reference number" },
  notes: { type: "string", description: "Free-form notes shown on the invoice" },
  terms: { type: "string", description: "Terms & conditions block" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "status", "customer_id_filter"]);

export default {
  name: "invoices",
  actions: {
    list: {
      method: "GET",
      path: "/invoices",
      description: "List invoices. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        status: { type: "string", description: "Filter by status: draft | sent | paid | overdue | void" },
        customer_id_filter: { type: "string", description: "Filter by customer id" },
      },
    },
    get: {
      method: "GET",
      path: "/invoices/:id",
      description: "Fetch a single invoice by id.",
      flags: { id: { type: "string", required: true, description: "Invoice id" } },
    },
    create: {
      method: "POST",
      path: "/invoices",
      description: "Create an invoice. Pass --body to supply `line_items[]`.",
      flags: { ...COMMON_BODY_FLAGS },
    },
    update: {
      method: "PUT",
      path: "/invoices/:id",
      description: "Update an invoice. Paid invoices reject edits to `line_items`.",
      flags: {
        id: { type: "string", required: true, description: "Invoice id" },
        ...COMMON_BODY_FLAGS,
      },
    },
    delete: {
      method: "DELETE",
      path: "/invoices/:id",
      description: "Delete an invoice.",
      flags: { id: { type: "string", required: true, description: "Invoice id" } },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
