// `inventory-adjustments` resource. Manual stock corrections (count audits,
// damage write-offs). `line_items[]` (item_id + quantity_adjusted) is array-
// shaped — supply via --body.
const COMMON_BODY_FLAGS = {
  body: { type: "string", description: "Raw JSON body — required when supplying `line_items[]`" },
  date: { type: "string", description: "Adjustment date (YYYY-MM-DD)" },
  reason: { type: "string", description: "Reason: stock_count | damaged | other" },
  description: { type: "string", description: "Free-form description" },
  adjustment_type: { type: "string", description: "quantity | value" },
};

const NON_BODY_KEYS = new Set(["id", "body", "page", "per_page", "from_date", "to_date"]);

export default {
  name: "inventory-adjustments",
  actions: {
    list: {
      method: "GET",
      path: "/inventoryadjustments",
      description: "List inventory adjustments. Pass --all to auto-paginate.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
        from_date: { type: "string", description: "Filter: adjustments on/after (YYYY-MM-DD)" },
        to_date: { type: "string", description: "Filter: adjustments on/before (YYYY-MM-DD)" },
      },
    },
    get: {
      method: "GET",
      path: "/inventoryadjustments/:id",
      description: "Fetch a single inventory adjustment by id.",
      flags: { id: { type: "string", required: true, description: "Adjustment id" } },
    },
    create: {
      method: "POST",
      path: "/inventoryadjustments",
      description: "Create an inventory adjustment. Pass --body to supply `line_items[]`.",
      flags: { ...COMMON_BODY_FLAGS },
    },
  },
  buildPayload(values) {
    const out = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === undefined || NON_BODY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  },
};
