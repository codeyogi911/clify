// `organizations` resource — read-only listing of organizations the user has
// access to. The org id selected here is what the rest of the CLI scopes
// requests by (set via ZOHO_INVENTORY_ORG_ID, see lib/api.mjs).
export default {
  name: "organizations",
  actions: {
    list: {
      method: "GET",
      path: "/organizations",
      description: "List organizations available to the authenticated user.",
      flags: {
        page: { type: "string", description: "Page number (default 1)" },
        per_page: { type: "string", description: "Items per page (default 200)" },
      },
    },
    get: {
      method: "GET",
      path: "/organizations/:id",
      description: "Fetch a single organization by id.",
      flags: {
        id: { type: "string", required: true, description: "Organization id" },
      },
    },
  },
  buildPayload() { return {}; },
};
