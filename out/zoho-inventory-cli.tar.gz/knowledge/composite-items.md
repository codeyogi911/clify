---
type: business-rule
applies-to: ["composite-items.create", "composite-items.update", "composite-items.get"]
source: docs
confidence: high
extracted: 2026-04-26
---

A **composite item** in Zoho is a kit / assembly: one parent item that consumes a fixed bundle of component items each time one composite unit is "assembled." This drives a stock-coupling rule that's the most common source of order-failure surprises.

## The data shape

```jsonc
// POST /compositeitems
{
  "name": "Gift Basket - Holiday",
  "sku": "BASKET-HOL",
  "rate": "49.99",
  "mapped_items": [
    { "item_id": "5210000000123",  "quantity": 1 },   // basket
    { "item_id": "5210000000456",  "quantity": 3 },   // chocolates
    { "item_id": "5210000000789",  "quantity": 1 }    // greeting card
  ]
}
```

`mapped_items[]` references **existing** items by id. Each entry's `quantity` is consumed when one unit of the composite is assembled.

## The assembly-stock rule

Composite items have **two separate stock levels**:

1. **Composite stock** — how many ready-to-sell composites are on hand. Goes up via `composite-items` assembly events (a separate Bundles API not exposed here), goes down on shipment.
2. **Component stock** — the inventory of each `mapped_items[].item_id`.

When a composite is sold (via `sales-orders`), Zoho **does not auto-assemble**. The composite must already have positive `composite stock`. If you submit a sales order for 5 composites and only 3 have been assembled, the order is created but flagged with a stock warning — the remaining 2 will not deduct from the components automatically.

## Update constraints

- ❌ You cannot remove an item from `mapped_items[]` if any composite stock has already been assembled with the old recipe — Zoho rejects with `code: 1001` ("recipe locked while composite stock exists"). Disassemble the standing stock first.
- ❌ You cannot rename a composite while open sales orders reference it; updates that change `name`/`sku` while there are non-terminal orders return `409 conflict`.
- ✅ You can change `rate` (selling price) freely; existing orders preserve their captured price.

## Anti-patterns

- ❌ Don't equate "this composite is in `mapped_items` of N other composites" with deletability. Zoho allows deletion of a composite even when it's a sub-component, but every parent composite then breaks at next assembly.
- ❌ Don't try to derive component depletion from sales orders — the assembly event is the only thing that touches component stock.
