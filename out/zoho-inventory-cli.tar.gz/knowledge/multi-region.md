---
type: business-rule
applies-to: ["*"]
source: docs
confidence: high
extracted: 2026-04-26
---

Zoho operates **independent data centers per region**. A token issued in one region cannot read or refresh against another — they don't share state. The region is fixed at the time the user signed up for Zoho and is encoded in two hostnames: the API host and the accounts (OAuth) host.

## Region map

| Region | Code | API host | Accounts (OAuth) host |
|---|---|---|---|
| United States | `com`     | `https://www.zohoapis.com/inventory/v1`     | `https://accounts.zoho.com/oauth/v2/token`     |
| Europe        | `eu`      | `https://www.zohoapis.eu/inventory/v1`      | `https://accounts.zoho.eu/oauth/v2/token`      |
| India         | `in`      | `https://www.zohoapis.in/inventory/v1`      | `https://accounts.zoho.in/oauth/v2/token`      |
| Australia     | `com.au`  | `https://www.zohoapis.com.au/inventory/v1`  | `https://accounts.zoho.com.au/oauth/v2/token`  |
| Japan         | `jp`      | `https://www.zohoapis.jp/inventory/v1`      | `https://accounts.zoho.jp/oauth/v2/token`      |
| Canada        | `ca`      | `https://www.zohoapis.ca/inventory/v1`      | `https://accounts.zohocloud.ca/oauth/v2/token` |
| China         | `com.cn`  | `https://www.zohoapis.com.cn/inventory/v1`  | `https://accounts.zoho.com.cn/oauth/v2/token`  |
| Saudi Arabia  | `sa`      | `https://www.zohoapis.sa/inventory/v1`      | `https://accounts.zoho.sa/oauth/v2/token`      |

Note: Canada's accounts host is `zohocloud.ca`, **not** `zoho.ca` — every other region matches the API host's TLD.

## Selecting the region

Set `ZOHO_INVENTORY_REGION` in `.env` (or the environment). The CLI defaults to `com`. The chosen region is used to build `BASE_URL` in `lib/api.mjs`:

```
ZOHO_INVENTORY_REGION=eu zoho-inventory-cli organizations list
```

## How to confirm the region for a fresh user

The OAuth refresh response includes an `api_domain` field — that domain is the truth. If `api_domain` is `https://www.zohoapis.eu` but the CLI is configured with `ZOHO_INVENTORY_REGION=com`, every request will 401.

## Anti-patterns

- ❌ Don't ask the user to "pick a region" at install time without offering a self-check. Use `organizations list` against each candidate; the right region returns 200, the wrong one 401.
- ❌ Don't set `ZOHO_INVENTORY_BASE_URL` and `ZOHO_INVENTORY_REGION` simultaneously — `BASE_URL` wins (see `lib/api.mjs`) and the region is silently ignored.
