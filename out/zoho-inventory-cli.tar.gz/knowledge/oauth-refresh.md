---
type: business-rule
applies-to: ["organizations.list", "items.list", "contacts.list", "sales-orders.list", "invoices.list"]
source: docs
confidence: high
extracted: 2026-04-26
---

Zoho Inventory uses OAuth 2.0 with **rotating access tokens and a long-lived refresh token**. The CLI itself does not refresh — it sends whatever access token it has and surfaces `auth_invalid` (HTTP 401) when the server rejects. The agent loop owns the refresh.

## The pieces

- **Access token** — short-lived (60 minutes). Sent as `Authorization: Zoho-oauthtoken <access_token>` (Zoho-specific prefix, **not** RFC 6750 `Bearer`).
- **Refresh token** — issued once when you authorize an `offline` Self Client. It does not expire on a schedule, but it is invalidated if the client secret rotates or the user revokes consent.
- **Client id + client secret** — registered at https://api-console.zoho.com.

## Refresh request

When `auth_invalid` fires (or proactively before the 60-minute window closes), POST to the **regional accounts host** (see `knowledge/multi-region.md`):

```
POST https://accounts.zoho.<region>/oauth/v2/token
Content-Type: application/x-www-form-urlencoded

refresh_token=<refresh_token>
&client_id=<client_id>
&client_secret=<client_secret>
&grant_type=refresh_token
```

Response is `{ access_token, expires_in, token_type, api_domain }`. Store the new `access_token` (e.g. `zoho-inventory-cli login --token <new>`) and retry the original request.

## Region matters

The accounts host **must match the user's data center** — a US user (`accounts.zoho.com`) cannot refresh against `accounts.zoho.eu`. The api_domain field in the refresh response confirms which `zohoapis.<region>` host serves this token's data.

## Anti-patterns

- ❌ Don't loop refresh more than once per command. If the second `auth_invalid` follows a successful refresh, the refresh_token itself has been revoked — surface to the user, don't retry indefinitely.
- ❌ Don't store the refresh_token in `~/.config/zoho-inventory-cli/credentials.json` next to the access token unless you also encrypt it. The login store is mode 0600 but plain JSON; treat it like a secrets file.
- ❌ Don't send `Authorization: Bearer <token>`. Zoho's API gateway strips standard Bearer for non-Zoho prefixes and 401s.
