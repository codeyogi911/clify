---
type: pattern
applies-to: ["*"]
source: docs
confidence: high
extracted: 2026-04-26
---

Zoho Inventory enforces **two independent rate limits**: a per-minute burst cap and a per-day plan-tier cap. Hitting either returns HTTP 429 with the Zoho envelope `{ "code": 45, "message": "..." }`.

## Limits

| Limit | Value | Resets |
|---|---|---|
| Per minute, per organization | 100 requests | rolling 60s |
| Per day — Free plan          | 1,000        | UTC midnight |
| Per day — Standard           | 2,000        | UTC midnight |
| Per day — Professional       | 5,000        | UTC midnight |
| Per day — Premium            | 10,000       | UTC midnight |
| Per day — Enterprise         | 10,000       | UTC midnight |
| Concurrent calls — Free      | 5            | n/a |
| Concurrent calls — Paid      | 10 (soft)    | n/a |

## CLI behavior on 429

The CLI does **not** retry. It surfaces the structured error:

```json
{ "type": "error", "code": "rate_limited", "retryable": true, "retryAfter": 30 }
```

`retryAfter` is populated when the response carries a `Retry-After` header. For the per-minute limit, that's typically 30–60s. For the per-day limit, Zoho often omits `Retry-After` because the wait is "until UTC midnight" — the agent loop should treat absence of `retryAfter` as "long wait, do not auto-retry."

## Distinguishing minute-cap from day-cap

The `message` field differs:

- Minute cap: `"too many requests per minute, please retry after some time"`
- Day cap: `"daily API call limit exceeded"` — only resets at UTC midnight

If you see the day-cap message, stop the workflow; retrying inside the same UTC day will not succeed.

## Anti-patterns

- ❌ Don't fan out `--all` paginated reads across many resources in parallel. With 200 records/page and a 100/min cap, even modest accounts hit the limit on the first scan.
- ❌ Don't ignore `Retry-After` and retry on a fixed delay — Zoho occasionally returns 429 with `Retry-After: 5` and you'll burn the daily quota fast.
